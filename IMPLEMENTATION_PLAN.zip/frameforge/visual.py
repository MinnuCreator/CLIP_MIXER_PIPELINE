"""FrameForge V3 Visual Understanding, Multimodal CLIP & Prompt-Image Consistency Engine."""
from __future__ import annotations

import hashlib
import json
import logging
import math
import os
from pathlib import Path
from typing import Any, Optional

from .config import DEFAULT_CONFIG, FrameForgeConfig
from .models import ImageAsset

logger = logging.getLogger("frameforge.visual")


class VisualUnderstandingEngine:
    """Multimodal vision-language understanding engine.
    
    Supports direct visual pixel embeddings (via CLIP when locally available),
    automated visual attribute/lighting extraction, and prompt-image consistency
    scoring for 3-way alignment.
    """
    _instance: Optional[VisualUnderstandingEngine] = None
    _clip_model: Any = None
    _clip_loaded: bool = False
    _is_fallback: bool = False

    def __new__(cls, config: Optional[FrameForgeConfig] = None) -> VisualUnderstandingEngine:
        if cls._instance is None:
            cls._instance = super().__new__(cls)
            cls._instance._init_engine(config or DEFAULT_CONFIG)
        elif config is not None:
            cls._instance.config = config
            cls._instance.cache_dir = Path(config.cache_dir) / "v3" / "visual_embeddings"
            cls._instance.cache_dir.mkdir(parents=True, exist_ok=True)
        return cls._instance

    def _init_engine(self, config: FrameForgeConfig) -> None:
        self.config = config
        self.cache_dir = Path(config.cache_dir) / "v3" / "visual_embeddings"
        self.cache_dir.mkdir(parents=True, exist_ok=True)
        self._load_clip()

    def _load_clip(self) -> None:
        if self._clip_loaded:
            return

        if self.config.visual_model in {"none", "", "disabled"}:
            self._clip_model = None
            self._is_fallback = True
            self._clip_loaded = True
            return

        device = self.config.device
        if device == "auto":
            try:
                import torch
                device = "cuda" if torch.cuda.is_available() else "cpu"
            except ImportError:
                device = "cpu"

        # Try loading locally without blocking network requests
        try:
            from sentence_transformers import SentenceTransformer
            try:
                self._clip_model = SentenceTransformer(self.config.visual_model, device=device, local_files_only=True)
                self._is_fallback = False
                self._clip_loaded = True
                logger.info("CLIP multimodal vision model loaded from local cache.")
                return
            except Exception:
                pass
            
            logger.info("CLIP model not in local cache; activating local visual feature extraction + semantic text embedding.")
            self._clip_model = None
            self._is_fallback = True
            self._clip_loaded = True
        except Exception as exc:
            logger.info("SentenceTransformers not available (%s). Using visual feature extraction.", exc)
            self._clip_model = None
            self._is_fallback = True
            self._clip_loaded = True

    @property
    def has_clip(self) -> bool:
        return not self._is_fallback and self._clip_model is not None

    def make_cache_key(self, asset_hash: str) -> str:
        raw = f"{asset_hash}_visual_{self.config.visual_model_version}_{self.config.config_version}"
        return hashlib.sha256(raw.encode("utf-8")).hexdigest()

    def extract_visual_attributes(self, file_path: Path) -> dict[str, Any]:
        """Extract visual concepts, colors, and lighting attributes from image pixels."""
        try:
            from PIL import Image, ImageStat

            with Image.open(file_path) as img:
                img = img.convert("RGB")
                w, h = img.size
                thumb = img.resize((64, 64))
                stat = ImageStat.Stat(thumb)
                r, g, b = stat.mean[0], stat.mean[1], stat.mean[2]
                brightness = (r * 0.299 + g * 0.587 + b * 0.114) / 255.0

                tags = []
                # Lighting tags
                if brightness < 0.25:
                    tags.extend(["night", "dark", "shadow", "storm"])
                elif brightness > 0.70:
                    tags.extend(["bright", "daylight", "sunny", "clear"])
                elif brightness > 0.45 and r > b * 1.2:
                    tags.extend(["sunrise", "sunset", "golden", "warm"])

                # Color tone tags
                if b > r * 1.25 and b > g * 1.1:
                    tags.extend(["ocean", "sea", "water", "sky", "blue"])
                elif g > r * 1.2 and g > b * 1.1:
                    tags.extend(["forest", "nature", "green", "landscape"])
                elif r > g * 1.3 and r > b * 1.3:
                    tags.extend(["warm", "fire", "beacon", "light", "red"])

                return {
                    "mean_brightness": round(brightness, 4),
                    "dominant_rgb": (int(r), int(g), int(b)),
                    "visual_tags": list(set(tags)),
                }
        except Exception:
            return {"mean_brightness": 0.5, "dominant_rgb": (128, 128, 128), "visual_tags": []}

    def encode_images(self, assets: list[ImageAsset], batch_size: int = 32) -> Any:
        """Encode image visuals into normalized vector embeddings with multi-attribute caching."""
        if not self.has_clip:
            return None

        import numpy as np
        from PIL import Image

        embeddings: list[Optional[np.ndarray]] = [None] * len(assets)
        uncached_indices: list[int] = []
        uncached_images: list[Any] = []
        uncached_keys: list[str] = []

        for idx, asset in enumerate(assets):
            key = self.make_cache_key(asset.file_hash or hashlib.sha256(asset.filename.encode()).hexdigest())
            cache_file = self.cache_dir / f"{key}.json"

            if cache_file.is_file():
                try:
                    data = json.loads(cache_file.read_text(encoding="utf-8"))
                    embeddings[idx] = np.array(data, dtype=np.float32)
                    continue
                except Exception:
                    pass

            try:
                img = Image.open(asset.file_path).convert("RGB")
                uncached_indices.append(idx)
                uncached_images.append(img)
                uncached_keys.append(key)
            except Exception as exc:
                logger.warning("Could not open image for visual embedding %s: %s", asset.file_path, exc)

        if uncached_images:
            try:
                new_vecs = self._clip_model.encode(
                    uncached_images,
                    batch_size=batch_size,
                    normalize_embeddings=True,
                    show_progress_bar=False,
                )
                for local_idx, global_idx in enumerate(uncached_indices):
                    vec = new_vecs[local_idx]
                    embeddings[global_idx] = vec
                    k = uncached_keys[local_idx]
                    try:
                        (self.cache_dir / f"{k}.json").write_text(json.dumps(vec.tolist()), encoding="utf-8")
                    except Exception as exc:
                        logger.warning("Failed to write visual embedding cache: %s", exc)
            except Exception as exc:
                logger.warning("CLIP batch image encoding failed: %s", exc)

        dim = 512
        for idx in range(len(assets)):
            if embeddings[idx] is None:
                embeddings[idx] = np.zeros(dim, dtype=np.float32)

        return np.array(embeddings, dtype=np.float32)

    def encode_text(self, texts: list[str], batch_size: int = 64) -> Any:
        """Encode narration text into the same CLIP vector space."""
        if not self.has_clip:
            return None
        import numpy as np

        return np.array(
            self._clip_model.encode(texts, batch_size=batch_size, normalize_embeddings=True, show_progress_bar=False),
            dtype=np.float32,
        )

    def compute_prompt_image_consistency(self, assets: list[ImageAsset], batch_size: int = 64) -> list[float]:
        """Compute semantic consistency between image prompts and actual image pixels (Prompt <-> Image)."""
        import numpy as np

        if self.has_clip:
            try:
                prompts = [a.prompt for a in assets]
                img_vecs = self.encode_images(assets, batch_size=batch_size)
                prompt_vecs = self.encode_text(prompts, batch_size=batch_size)
                if img_vecs is not None and prompt_vecs is not None:
                    # Diagonal dot products: cosine similarity between each image vector and its prompt vector
                    dots = np.sum(img_vecs * prompt_vecs, axis=1)
                    # Normalize cosine [-1, 1] to [0, 1]
                    normalized_scores = (np.clip(dots, -1.0, 1.0) + 1.0) / 2.0
                    return [round(float(s), 4) for s in normalized_scores]
            except Exception as exc:
                logger.warning("CLIP prompt-image consistency computation failed: %s", exc)

        # Fallback visual attribute overlap
        scores = []
        for asset in assets:
            vis_tags = set(asset.metadata.get("visual_tags", []))
            prompt_words = set(asset.prompt.lower().split())
            if vis_tags and prompt_words:
                overlap = len(vis_tags & prompt_words) / max(1, len(vis_tags))
                scores.append(round(min(1.0, 0.4 + 0.6 * overlap), 4))
            else:
                scores.append(0.5)
        return scores
